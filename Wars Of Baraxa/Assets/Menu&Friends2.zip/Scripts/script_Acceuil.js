﻿function Update() {
		if(Input.anyKeyDown)
			Application.LoadLevel("Menu");
	}